# soccer-cup
Creating and managing football games for children and youth teams
