<?php
/*
 * Project: Entity
 * File: /Tournament.php
 * File Created: 2025-06-18, 20:15:56
 * Author: Wojciech Sobczak (wsobczak@gmail.com)
 * -----
 * Last Modified: 2025-06-20, 15:32:29
 * Modified By: Wojciech Sobczak (wsobczak@gmail.com)
 * -----
 * Copyright © 2021 - 2025 by vbert
 */

namespace App\Domain\Tournament\Entity;

use Doctrine\ORM\Mapping as ORM;

#[ORM\Entity]
#[ORM\Table(name: "tournament")]
class Tournament
{
    #[ORM\Id]
    #[ORM\GeneratedValue]
    #[ORM\Column]
    private ?int $id = null;

    #[ORM\Column(length: 200)]
    private string $name;

    #[ORM\Column(type: 'integer')]
    private int $year;

    #[ORM\Column(type: 'date')]
    private \DateTimeInterface $startDate;

    #[ORM\Column(type: 'date')]
    private \DateTimeInterface $endDate;

    #[ORM\Column(length: 20)]
    private string $status;

    #[ORM\Column(type: 'integer')]
    private int $maxPlayersPerTeam;

    // gettery/settery...

    public function getId(): ?int
    {
        return $this->id;
    }

    public function getName(): string
    {
        return $this->name;
    }
    public function setName(string $name): self
    {
        $this->name = $name;
        return $this;
    }

    public function getYear(): int
    {
        return $this->year;
    }
    public function setYear(int $year): self
    {
        $this->year = $year;
        return $this;
    }

    public function getStartDate(): \DateTimeInterface
    {
        return $this->startDate;
    }
    public function setStartDate(\DateTimeInterface $date): self
    {
        $this->startDate = $date;
        return $this;
    }

    public function getEndDate(): \DateTimeInterface
    {
        return $this->endDate;
    }
    public function setEndDate(\DateTimeInterface $date): self
    {
        $this->endDate = $date;
        return $this;
    }

    public function getStatus(): string
    {
        return $this->status;
    }
    public function setStatus(string $status): self
    {
        $this->status = $status;
        return $this;
    }

    public function getMaxPlayersPerTeam(): int
    {
        return $this->maxPlayersPerTeam;
    }
    public function setMaxPlayersPerTeam(int $max): self
    {
        $this->maxPlayersPerTeam = $max;
        return $this;
    }
}

