<?php
/*
 * Project: Controller
 * File: /HomeController.php
 * File Created: 2025-06-20, 15:38:27
 * Author: Wojciech Sobczak (wsobczak@gmail.com)
 * -----
 * Last Modified: 2025-06-27, 11:56:24
 * Modified By: Wojciech Sobczak (wsobczak@gmail.com)
 * -----
 * Copyright © 2021 - 2025 by vbert
 */

namespace App\Controller;

use Symfony\Component\HttpFoundation\Request;
use Symfony\Component\HttpFoundation\Response;
use Symfony\Component\Routing\Annotation\Route;
use App\Domain\Tournament\Repository\TournamentRepository;
use Symfony\Bundle\FrameworkBundle\Controller\AbstractController;


final class HomeController extends AbstractController
{
    #[Route('/', name: 'app_home')]
    public function index(Request $request, TournamentRepository $tournamentRepository): Response
    {
        $this->denyAccessUnlessGranted('tournament.create');

        return $this->render('home/index.html.twig', [
            'ongoing' => $tournamentRepository->findByStatus('ongoing'),
            'upcoming' => $tournamentRepository->findByStatus('upcoming'),
            'finished' => $tournamentRepository->findByStatus('finished')
        ]);
    }
}
