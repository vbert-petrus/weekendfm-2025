<?php
/*
 * Project: Controller
 * File: /SecurityController.php
 * File Created: 2025-06-26, 23:23:04
 * Author: Wojciech Sobczak (wsobczak@gmail.com)
 * -----
 * Last Modified: 2025-06-27, 13:11:19
 * Modified By: Wojciech Sobczak (wsobczak@gmail.com)
 * -----
 * Copyright © 2021 - 2025 by vbert
 */

namespace App\Controller;

use Symfony\Bundle\FrameworkBundle\Controller\AbstractController;
use Symfony\Component\HttpFoundation\Request;
use Symfony\Component\HttpFoundation\Response;
use Symfony\Component\Security\Csrf\CsrfTokenManagerInterface;
use Symfony\Component\Security\Http\Authentication\AuthenticationUtils;
use Symfony\Component\Routing\Annotation\Route;

class SecurityController extends AbstractController
{
    #[Route('/login', name: 'app_login')]
    public function login(
        Request $request,
        AuthenticationUtils $authenticationUtils,
        CsrfTokenManagerInterface $csrfTokenManager
    ): Response
    {
        // pobierz ostatni błąd logowania (jeśli był)
        $error = $authenticationUtils->getLastAuthenticationError();

        // ostatnio wpisany email
        $lastUsername = $authenticationUtils->getLastUsername();

        return $this->render('security/login.html.twig', [
            'last_username' => $lastUsername,
            'error' => $error,
            '_csrf_token' => $csrfTokenManager->getToken('authenticate')->getValue(),
        ]);
    }

    #[Route('/logout', name: 'app_logout')]
    public function logout(Request $request): void
    {
        // ten kod nie jest nigdy wywoływany, Symfony zajmie się wylogowaniem
        throw new \LogicException('This method can be blank - it will be intercepted by the logout key on your firewall.');
    }
}
