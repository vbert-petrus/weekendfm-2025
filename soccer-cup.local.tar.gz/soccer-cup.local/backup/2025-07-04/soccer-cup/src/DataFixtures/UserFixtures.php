<?php
/*
 * Project: DataFixtures
 * File: /UserFixtures.php
 * File Created: 2025-06-20, 22:44:07
 * Author: Wojciech Sobczak (wsobczak@gmail.com)
 * -----
 * Last Modified: 2025-06-26, 22:14:02
 * Modified By: Wojciech Sobczak (wsobczak@gmail.com)
 * -----
 * Copyright © 2021 - 2025 by vbert
 */

namespace App\DataFixtures;

use App\Domain\User\Entity\User;
use App\Domain\User\Entity\Role;
use Doctrine\Bundle\FixturesBundle\Fixture;
use Doctrine\Persistence\ObjectManager;
use Symfony\Component\PasswordHasher\Hasher\UserPasswordHasherInterface;

class UserFixtures extends Fixture
{
    public function __construct(
        private UserPasswordHasherInterface $passwordHasher
    ) {}

    public function load(ObjectManager $manager): void
    {
        $usersData = [
            [
                'name' => 'Test Super Admin',
                'email' => 'root@soccer.local',
                'password' => 'rootpass',
                'roles' => ['ROLE_ROOT'],
            ],
            [
                'name' => 'Test Admin',
                'email' => 'admin@soccer.local',
                'password' => 'adminpass',
                'roles' => ['ROLE_ADMIN'],
            ],
            [
                'name' => 'Test Coach',
                'email' => 'coach@soccer.local',
                'password' => 'coachpass',
                'roles' => ['ROLE_COACH'],
            ],
            [
                'name' => 'Test Referee',
                'email' => 'referee@soccer.local',
                'password' => 'refereepass',
                'roles' => ['ROLE_REFEREE'],
            ],
        ];

        foreach ($usersData as $data) {
            $user = new User();
            $user->setName($data['name']);
            $user->setEmail($data['email']);

            $hashedPassword = $this->passwordHasher->hashPassword($user, $data['password']);
            $user->setPassword($hashedPassword);

            foreach ($data['roles'] as $roleName) {
                $role = $manager->getRepository(Role::class)->findOneBy(['name' => $roleName]);

                if (!$role) {
                    throw new \RuntimeException('Brak wymaganej roli w bazie.');
                } else {
                    $user->addRoleEntity($role);
                }
            }

            $user->setRoles($data['roles']);

            $manager->persist($user);
        }

        $manager->flush();
    }
}
