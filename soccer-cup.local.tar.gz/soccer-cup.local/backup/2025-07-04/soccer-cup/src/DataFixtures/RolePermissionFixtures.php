<?php
/*
 * Project: DataFixtures
 * File: /RolePermissionFixtures.php
 * File Created: 2025-06-20, 21:11:58
 * Author: Wojciech Sobczak (wsobczak@gmail.com)
 * -----
 * Last Modified: 2025-06-20, 23:28:18
 * Modified By: Wojciech Sobczak (wsobczak@gmail.com)
 * -----
 * Copyright © 2021 - 2025 by vbert
 */

namespace App\DataFixtures;

use App\Domain\User\Entity\Permission;
use App\Domain\User\Entity\Role;
use Doctrine\Bundle\FixturesBundle\Fixture;
use Doctrine\Persistence\ObjectManager;

class RolePermissionFixtures extends Fixture
{
    public function load(ObjectManager $manager): void
    {
        // 1. Tworzenie i zapisanie uprawnień
        $permissionsList = [
            'user.create',
            'user.edit',
            'user.delete',
            'tournament.create',
            'tournament.edit',
            'tournament.delete',
            'team.manage',
            'match.edit',
            'player.view',
        ];

        $permissions = [];

        foreach ($permissionsList as $name) {
            $permission = new Permission();
            $permission->setName($name);
            $manager->persist($permission);
            $permissions[$name] = $permission;
        }

        // 2. Tworzenie ról i przypisywanie im uprawnień
        $roles = [
            'ROLE_ROOT' => $permissionsList, // pełny dostęp
            'ROLE_ADMIN' => [
                'user.create', 'user.edit',
                'tournament.create', 'tournament.edit'
            ],
            'ROLE_TOURNAMENT_ADMIN' => [
                'tournament.create', 'tournament.edit'
            ],
            'ROLE_COACH' => [
                'player.view', 'team.manage',
            ],
            'ROLE_REFEREE' => [
                'match.edit', 'player.view',
            ],
        ];

        foreach ($roles as $roleName => $rolePermissions) {
            $role = new Role();
            $role->setName($roleName);

            foreach ($rolePermissions as $permName) {
                $role->addPermission($permissions[$permName]);
            }

            $manager->persist($role);
        }

        $manager->flush();
    }
}
