<?php
/*
 * Project: Security
 * File: /LoginAuthenticator.php
 * File Created: 2025-06-26, 22:55:12
 * Author: Wojciech Sobczak (wsobczak@gmail.com)
 * -----
 * Last Modified: 2025-06-27, 13:36:33
 * Modified By: Wojciech Sobczak (wsobczak@gmail.com)
 * -----
 * Copyright © 2021 - 2025 by vbert
 */

namespace App\Security;

use Psr\Log\LoggerInterface;
use Symfony\Component\HttpFoundation\RedirectResponse;
use Symfony\Component\HttpFoundation\Request;
use Symfony\Component\HttpFoundation\Response;
use Symfony\Component\Routing\RouterInterface;
use Symfony\Component\Security\Http\Authenticator\AbstractLoginFormAuthenticator;
use Symfony\Component\Security\Http\Authenticator\Passport\Badge\CsrfTokenBadge;
use Symfony\Component\Security\Http\Authenticator\Passport\Badge\RememberMeBadge;
use Symfony\Component\Security\Http\Authenticator\Passport\Credentials\PasswordCredentials;
use Symfony\Component\Security\Http\Authenticator\Passport\Passport;
use Symfony\Component\Security\Http\Authenticator\Passport\Badge\UserBadge;
use Symfony\Component\Security\Core\Authentication\Token\TokenInterface;
use Symfony\Component\Security\Core\Exception\AuthenticationException;
use Symfony\Component\Security\Http\Util\TargetPathTrait;

class LoginAuthenticator extends AbstractLoginFormAuthenticator
{
    use TargetPathTrait;

    public const LOGIN_ROUTE = 'app_login';

    public function __construct(
        private RouterInterface $router,
        private LoggerInterface $logger
    ) {
    }

    public function authenticate(Request $request): Passport
    {
        if (headers_sent()) {
            $this->logger->error('Headers already sent before authentication!');
        }
        $this->logger->info('Authentication started.');
        $this->logger->info('Session ID: ' . session_id());
        $this->logger->info('Session started? ' . (session_status() === PHP_SESSION_ACTIVE ? 'yes' : 'no'));
        $token = $request->request->get('_csrf_token');
        $this->logger->info('Token from form: ' . $token);


        $email = $request->request->get('email', '');
        $request->getSession()->set('_security.last_username', $email);

        $this->logger->info('Email from form: ' . $email);
        $this->logger->info('Raw POST data: ' . json_encode($request->request->all()));

        // $csrfToken = new CsrfToken('authenticate', $request->request->get('_csrf_token'));
        // if (!$this->csrfTokenManager->isTokenValid($csrfToken)) {
        //     throw new InvalidCsrfTokenException();
        // }

        return new Passport(
            new UserBadge($email),
            new PasswordCredentials($request->request->get('password', ''))
            // ,
            // [
            //     new CsrfTokenBadge('authenticate', $request->request->get('_csrf_token')),
            //     new RememberMeBadge(),
            // ]
        );
    }

    public function onAuthenticationSuccess(Request $request, TokenInterface $token, string $firewallName): ?Response
    {
        $targetPath = $this->getTargetPath($request->getSession(), $firewallName);

        if ($targetPath) {
            return new RedirectResponse($targetPath);
        }

        return new RedirectResponse($this->router->generate('app_home'));
    }

    public function start(Request $request, ?AuthenticationException $authException = null): Response
    {
        return new RedirectResponse($this->router->generate(self::LOGIN_ROUTE));
    }

    public function supports(Request $request): bool
    {
        $isPost = $request->isMethod('POST');
        $route = $request->attributes->get('_route');

        return $isPost && $route === self::LOGIN_ROUTE;
    }

    // public function supports(Request $request): bool
    // {
    //     $this->logger->info('Coś się dzieje w supports()', [
    //         'method' => $request->getMethod(),
    //         'path' => $request->getPathInfo(),
    //     ]);

    //     return $request->getPathInfo() === '/login';
    // }

    protected function getLoginUrl(Request $request): string
    {
        return $this->router->generate(self::LOGIN_ROUTE);
    }
}
