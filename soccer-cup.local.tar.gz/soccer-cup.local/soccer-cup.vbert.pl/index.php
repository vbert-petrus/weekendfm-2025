<?php
$domainName = 'soccer-cup.vbert.pl';
?>

<!DOCTYPE html>
<html lang="pl">
<head>
  <meta charset="UTF-8">
  <meta http-equiv="X-UA-Compatible" content="IE=edge">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <link rel="canonical" href="https://soccer-cup.vbert.pl/">
  <meta name="description" content="Application for creating and managing football tournaments: Junior Cup">
  <meta name="author" content="Wojciech Sobczak (vbert)"></meta>
  <link rel="icon" href="favicon.ico" type="image/x-icon">
  <title><?=$domainName;?></title>
</head>
<body>
    <h1><?=$domainName;?></h1>
</body>
</html>