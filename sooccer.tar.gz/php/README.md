# Rozgrywki Junior Cup

### Projekt: 

Tworzenie i zarządzanie rozgrywkami piłki nożnej: Junior Cup

### Założenia:

1. Junior Cup może składać się z jednego lub kilku Turniejów. 
2. Pojedynczy Turniej to rozgrywki między drużynami tego samego rocznika (rok daty urodzenia zawodników). Np. Turniej o id=1 to drużyny z rocznika 2014, Turniej o id=2 to drużyny z rocznika 2016.
3. W Turnieju może brać dowolna ilość drużyn, które w pierwszym etapie dzielone są na grupy o równej ilości drużyn. To znaczy, że pierwszy etap turnieju to rozgrywki grupowe.
4. Drużyny mogą składać się z różnej ilości zawodników, ale w danym Turnieju (roczniku) te ilości muszą być takie same (definiowanie ilości zawodników w drużynie przy definiowaniu Turnieju).
5. Po zakończeniu rozgrywek grupowych następuje faza pucharowa.

### Implementacja:

1. Podział na część prezentacyjną (publiczną) i administracyjną z modułem autoryzacji.
2. Moduł autoryzacji ma posiadać możliwość dodawania użytkowników oraz przydzielanie im różnych uprawnień do różnych modułów aplikacji.
3. Uprawnienia dla trenerów / kierowników drużyn mają zezwalać tylko na dostęp do tworzenia własnych drużyn i modyfikacje ich, bez możliwości edycji drużyn innych treneró / kierowników.
4. Aplikacja ma posiadać budowę modułową. 
5. Moduł rozgrywek w systemie pucharowym ma posiadać możliwość generowania drabinki turniejowej wg  definiowanych zasad. Mogą być dwie wstępnie zdefiniowane: jedna generowanie par na podstawie wyników z fazy grupowej, druga: ustawianie losowe par.

### Technologia:

1. Aplikacja ma zostać stworzona w PHP minimum 8.3, a jako repozytorium danych posłuży baza danych MySQL. 
2. Architektura modułowa zgodna z zasadami SOLID i wykorzystaniem wzorców projektowych.
3. Konieczna walidacja wprowadzanych danych oraz obsług`a błędów, wyjątków.
4. Przydałby się moduł do logowania w bazie danych zmian i zdarzeń (timestamp, identyfikator użytkownika, co zostało zmienione w jakim module / obiekcie).

### Moduły:

1. **JuniorCup** - definicja nadrzędnego turnieju (root), ustawienia wspólne dla wszystkich turniejów składowych (ilość turniejów, ilość drużyn, liczności drużyn).
2. **Turniej** – zarządzanie turniejami składowymi.
3. **Zawodnik** - zarządzanie zawodnikami.
4. **Drużyna** - zarządzanie drużynami, przypisanie zawodników.
5. **Grupy** – podział drużyn na grupy.
6. **Mecze grupowe** – zarządzanie meczami w fazie grupowej, mecz ma posiadać godzinę o której ma się odbyć.
7. **Faza pucharowa** – obsługa drabinki turniejowej.
8. **Autoryzacja**, **Użytkownicy** i ich **Role**
9. **Logs** - logowanie zdarzeń.

