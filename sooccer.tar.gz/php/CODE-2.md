## 1. Inicjalizacja projektu Symfony

### 1.1. Stwórz nowy projekt

```bash
composer create-project symfony/skeleton soccer-cup
cd soccer-cup
```

### 1.2. Zainstaluj potrzebne pakiety

```bash
# web server + templating
composer require symfony/web-server-bundle twig
# Doctrine ORM
composer require symfony/orm-pack
composer require --dev symfony/maker-bundle
# Security (autoryzacja, role)
composer require symfony/security-bundle
# Validator, Logger
composer require symfony/validator monolog
```

### 1.3. Konfiguracja bazy danych

W pliku `.env` ustaw DSN do MySQL, np.:

```bash
DATABASE_URL="mysql://db_user:db_password@127.0.0.1:3306/soccer_cup?serverVersion=8.0"
```

### 1.4. Generator encji

Dzięki `maker-bundle` łatwo wygenerujesz kolejne encje:

```bash
php bin/console make:entity
```



## 2. Wstępny model encji (ERD)

Poniżej lista głównych encji i ich kluczowe powiązania:

| Encja          | Klucz główny | Relacje                      | Uwagi                                                        |
| -------------- | ------------ | ---------------------------- | ------------------------------------------------------------ |
| **SoccerCup**  | `id`         | 1–* `Tournament`             | Root: wspólne ustawienia (np. liczba turnamentów składowych) |
| **Tournament** | `id`         | *–1 `SoccerCup`1–* `Team`    | Jeden year, definiujesz tu liczbę zawodników w drużynie      |
| **Team**       | `id`         | *–1 `Tournament`1–* `Player` | Przynależność do turnamentu                                  |
| **Player**     | `id`         | *–1 `Team`                   |                                                              |
| **Group**      | `id`         | *–1 `Tournament`*–* `Team`   | Drużyny w grupie                                             |
| **Game**       | `id`         | 2× *–1 `Team`*–1 `Group`     | Dla fazy grupowej: `group_id`; godzina, miejsce              |
| **CupPhase**   | `id`         | *–1 `Tournament`*–* `Game`   | Drabinka, relacje do meczów pucharowych                      |
| **User**       | `id`         | *–* `Role`                   | Trenerzy, admini                                             |
| **Role**       | `id`         | *–* `Permission`             | Nazwa roli (np. ROLE_COACH)                                  |
| **Permission** | `id`         |                              | Szczegółowe prawa (np. drużyna-edit-own)                     |
| **Log**        | `id`         | *–1 `User`                   | Zdarzenia z opisem, timestamp                                |

**Uwaga**: relacje *–* oznaczają wiele-do-wielu, a *–1 / 1–* jedno-do-wielu.



## 3. Encje:

### 3.1. SoccerCup

```php
<?php
// src/Entity/SoccerCup.php
namespace App\Entity;

use Doctrine\ORM\Mapping as ORM;
use Doctrine\Common\Collections\ArrayCollection;
use Doctrine\Common\Collections\Collection;

/**
 * @ORM\Entity
 * @ORM\Table(name="soccer_cup")
 */
class SoccerCup
{
    /** 
     * @ORM\Id @ORM\GeneratedValue @ORM\Column(type="integer") 
     */
    private int $id;

    /** 
     * Nazwa nadrzędnego cyklu turnamentów
     * @ORM\Column(type="string", length=100) 
     */
    private string $name;

    /**
     * @ORM\OneToMany(targetEntity="App\Entity\Tournament", mappedBy="soccerCup", cascade={"persist","remove"})
     */
    private Collection $turnaments;

    public function __construct()
    {
        $this->turnaments = new ArrayCollection();
    }
  
    public function addTournament(Tournament $turnament): self
    {
        if (!$this->turnaments->contains($turnament)) {
            $this->turnaments->add($turnament);
            $turnament->setSoccerCup($this);
        }
        return $this;
    }

    public function removeTournament(Tournament $turnament): self
    {
        if ($this->turnaments->removeElement($turnament)) {
            // opcjonalnie: odwiąż relację
            if ($turnament->getSoccerCup() === $this) {
                $turnament->setSoccerCup(null);
            }
        }
        return $this;
    }


    // getters/setters...
}
```

### 3.2. Tournament

```php
<?php
// src/Entity/Turnament.php
namespace App\Entity;

use Doctrine\ORM\Mapping as ORM;
use Doctrine\Common\Collections\ArrayCollection;
use Doctrine\Common\Collections\Collection;
use Symfony\Component\Validator\Constraints as Assert;

/**
 * @ORM\Entity
 * @ORM\Table(name="turnament")
 */
class Turnament
{
    /** 
     * @ORM\Id @ORM\GeneratedValue @ORM\Column(type="integer") 
     */
    private int $id;

    /** 
     * @ORM\Column(type="integer") 
     * @Assert\Positive 
     */
    private int $year;

    /** 
     * @ORM\Column(type="smallint") 
     * @Assert\Positive 
     */
    private int $teamSize;

    /**
     * @ORM\ManyToOne(targetEntity="App\Entity\SoccerCup", inversedBy="turnaments")
     * @ORM\JoinColumn(nullable=false)
     */
    private SoccerCup $soccerCup;

    /**
     * @ORM\OneToMany(targetEntity="App\Entity\Team", mappedBy="turnament", cascade={"persist","remove"})
     */
    private Collection $teams;

    /**
     * @ORM\OneToMany(targetEntity="App\Entity\Group", mappedBy="turnament", cascade={"persist","remove"})
     */
    private Collection $groups;

    /**
     * @ORM\OneToMany(targetEntity="App\Entity\CupPhase", mappedBy="turnament", cascade={"persist","remove"})
     */
    private Collection $cupPhases;

    public function __construct()
    {
        $this->teams = new ArrayCollection();
        $this->groups = new ArrayCollection();
        $this->cupPhases = new ArrayCollection();
    }
  
    public function addTeam(Team $team): self
    {
        if (!$this->teams->contains($team)) {
            $this->teams->add($team);
            $team->setTurnament($this);
        }
        return $this;
    }

    public function removeTeam(Team $team): self
    {
        if ($this->teams->removeElement($team)) {
            if ($team->getTurnament() === $this) {
                $team->setTurnament(null);
            }
        }
        return $this;
    }

    public function addGrupa(Grupa $group): self
    {
        if (!$this->groups->contains($group)) {
            $this->groups->add($group);
            $group->setTurnament($this);
        }
        return $this;
    }

    public function removeGrupa(Group $group): self
    {
        if ($this->groups->removeElement($group)) {
            if ($group->getTurnament() === $this) {
                $group->setTurnament(null);
            }
        }
        return $this;
    }

    public function addCupPhase(CupPhase $phase): self
    {
        if (!$this->cupPhases->contains($phase)) {
            $this->cupPhases->add($phase);
            $phase->setTurnament($this);
        }
        return $this;
    }

    public function removeCupPhase(CupPhase $phase): self
    {
        if ($this->cupPhases->removeElement($phase)) {
            if ($phase->getTurnament() === $this) {
                $phase->setTurnament(null);
            }
        }
        return $this;
    }


    // getters/setters...
}
```

### 3.3 Team

```php
<?php
// src/Entity/Team.php
namespace App\Entity;

use Doctrine\ORM\Mapping as ORM;
use Doctrine\Common\Collections\ArrayCollection;
use Doctrine\Common\Collections\Collection;

/**
 * @ORM\Entity
 * @ORM\Table(name="team")
 */
class Team
{
    /** 
     * @ORM\Id @ORM\GeneratedValue @ORM\Column(type="integer") 
     */
    private int $id;

    /** 
     * @ORM\Column(type="string", length=100) 
     */
    private string $name;

    /**
     * @ORM\ManyToOne(targetEntity="App\Entity\Tournament", inversedBy="teams")
     * @ORM\JoinColumn(nullable=false)
     */
    private Tournament $turnament;

    /**
     * @ORM\OneToMany(targetEntity="App\Entity\Player", mappedBy="team", cascade={"persist","remove"})
     */
    private Collection $players;

    /**
     * @ORM\ManyToMany(targetEntity="App\Entity\Group", inversedBy="teams")
     * @ORM\JoinTable(name="team_group")
     */
    private Collection $groups;

    /**
     * Właściciel / trener drużyny
     * @ORM\ManyToOne(targetEntity="App\Entity\User", inversedBy="teams")
     * @ORM\JoinColumn(nullable=false)
     */
    private User $owner;

    public function __construct()
    {
        $this->players = new ArrayCollection();
        $this->groups = new ArrayCollection();
    }

    public function addPlayer(Player $player): self
    {
        if (!$this->players->contains($player)) {
            $this->players->add($player);
            $player->setTeam($this);
        }
        return $this;
    }

    public function removePlayer(Player $player): self
    {
        if ($this->players->removeElement($player)) {
            if ($player->getTeam() === $this) {
                $player->setTeam(null);
            }
        }
        return $this;
    }

    public function addGroup(Group $group): self
    {
        if (!$this->groups->contains($group)) {
            $this->groups->add($group);
            $group->addTeam($this);
        }
        return $this;
    }

    public function removeGroup(Group $group): self
    {
        if ($this->groups->removeElement($group)) {
            $group->removeTeam($this);
        }
        return $this;
    }

    // getters/setters...
}
```

### 3.4. Player

```php
<?php
// src/Entity/Player.php
namespace App\Entity;

use Doctrine\ORM\Mapping as ORM;
use Symfony\Component\Validator\Constraints as Assert;

/**
 * @ORM\Entity
 * @ORM\Table(name="player")
 */
class Player
{
    /** 
     * @ORM\Id @ORM\GeneratedValue @ORM\Column(type="integer") 
     */
    private int $id;

    /** 
     * @ORM\Column(type="string", length=50) 
     * @Assert\NotBlank 
     */
    private string $first_name;

    /** 
     * @ORM\Column(type="string", length=50) 
     * @Assert\NotBlank 
     */
    private string $last_name;

    /** 
     * @ORM\Column(type="date") 
     * @Assert\Date 
     */
    private \DateTimeInterface $dateOfBirth;

    /**
     * @ORM\ManyToOne(targetEntity="App\Entity\Team", inversedBy="players")
     * @ORM\JoinColumn(nullable=false)
     */
    private Team $team;

    // getters/setters...
}
```

### 3.5. Group

```php
<?php
// src/Entity/Group.php
namespace App\Entity;

use Doctrine\ORM\Mapping as ORM;
use Doctrine\Common\Collections\ArrayCollection;
use Doctrine\Common\Collections\Collection;

/**
 * @ORM\Entity
 * @ORM\Table(name="group")
 */
class Group
{
    /** 
     * @ORM\Id @ORM\GeneratedValue @ORM\Column(type="integer") 
     */
    private int $id;

    /** 
     * @ORM\Column(type="string", length=10) 
     */
    private string $name;

    /**
     * @ORM\ManyToOne(targetEntity="App\Entity\Tournament", inversedBy="groups")
     * @ORM\JoinColumn(nullable=false)
     */
    private Tournament $turnament;

    /**
     * @ORM\ManyToMany(targetEntity="App\Entity\Team", mappedBy="groups")
     */
    private Collection $teams;

    /**
     * @ORM\OneToMany(targetEntity="App\Entity\Game", mappedBy="group", cascade={"persist","remove"})
     */
    private Collection $games;

    public function __construct()
    {
        $this->teams = new ArrayCollection();
        $this->games = new ArrayCollection();
    }

    public function addTeam(Team $team): self
    {
        if (!$this->teams->contains($team)) {
            $this->teams->add($team);
            $team->addGroup($this);
        }
        return $this;
    }

    public function removeTeam(Team $team): self
    {
        if ($this->teams->removeElement($team)) {
            $team->removeGroup($this);
        }
        return $this;
    }

    public function addGame(Game $game): self
    {
        if (!$this->games->contains($game)) {
            $this->games->add($game);
            $game->setGroup($this);
        }
        return $this;
    }

    public function removeGame(Game $game): self
    {
        if ($this->games->removeElement($game)) {
            if ($game->getGroup() === $this) {
                $game->setGroup(null);
            }
        }
        return $this;
    }

    // getters/setters...
}
```

### 3.6. Game

```php
<?php
// src/Entity/Game.php
namespace App\Entity;

use Doctrine\ORM\Mapping as ORM;
use Symfony\Component\Validator\Constraints as Assert;

/**
 * @ORM\Entity
 * @ORM\Table(name="game")
 */
class Game
{
    /** 
     * @ORM\Id @ORM\GeneratedValue @ORM\Column(type="integer") 
     */
    private int $id;

    /**
     * @ORM\ManyToOne(targetEntity="App\Entity\Team")
     * @ORM\JoinColumn(nullable=false)
     */
    private Team $host;

    /**
     * @ORM\ManyToOne(targetEntity="App\Entity\Team")
     * @ORM\JoinColumn(nullable=false)
     */
    private Team $guest;

    /**
     * Dla meczów grupowych – jeśli null, to pucharowy
     * @ORM\ManyToOne(targetEntity="App\Entity\Grupa", inversedBy="games")
     */
    private ?Grupa $group = null;

    /**
     * Dla fazy pucharowej
     * @ORM\ManyToOne(targetEntity="App\Entity\CupPhase", inversedBy="games")
     */
    private ?CupPhase $cupPhase = null;

    /** 
     * @ORM\Column(type="datetime") 
     * @Assert\NotNull 
     */
    private \DateTimeInterface $startDate;

    /** 
     * @ORM\Column(type="smallint", nullable=true) 
     */
    private ?int $hostGoals = null;

    /** 
     * @ORM\Column(type="smallint", nullable=true) 
     */
    private ?int $guestGoals = null;

    // getters/setters...
}
```

### 3.7. CupPhase

```php
<?php
// src/Entity/CupPhase.php
namespace App\Entity;

use Doctrine\ORM\Mapping as ORM;
use Doctrine\Common\Collections\ArrayCollection;
use Doctrine\Common\Collections\Collection;

/**
 * @ORM\Entity
 * @ORM\Table(name="cup_phase")
 */
class CupPhase
{
    /** 
     * @ORM\Id @ORM\GeneratedValue @ORM\Column(type="integer") 
     */
    private int $id;

    /**
     * @ORM\ManyToOne(targetEntity="App\Entity\Turnament", inversedBy="cupPhases")
     * @ORM\JoinColumn(nullable=false)
     */
    private Turnament $turnament;

    /**
     * @ORM\Column(type="string", length=20)
     */
    private string $type; // np. "LOSOWE" lub "GRUPOWE-1/4"

    /**
     * @ORM\OneToMany(targetEntity="App\Entity\Game", mappedBy="cupPhase", cascade={"persist","remove"})
     */
    private Collection $games;

    public function __construct()
    {
        $this->games = new ArrayCollection();
    }

    public function addGame(Game $game): self
    {
        if (!$this->games->contains($game)) {
            $this->games->add($game);
            $game->setCupPhase($this);
        }
        return $this;
    }

    public function removeGame(Game $game): self
    {
        if ($this->games->removeElement($game)) {
            if ($game->getCupPhase() === $this) {
                $game->setCupPhase(null);
            }
        }
        return $this;
    }

    // getters/setters...
}
```

### 3.8. User

```php
<?php
// src/Entity/User.php
namespace App\Entity;

use Doctrine\ORM\Mapping as ORM;
use Doctrine\Common\Collections\ArrayCollection;
use Doctrine\Common\Collections\Collection;
use Symfony\Component\Security\Core\User\UserInterface;

/**
 * @ORM\Entity
 * @ORM\Table(name="uzytkownik")
 */
class User implements UserInterface
{
    /** 
     * @ORM\Id @ORM\GeneratedValue @ORM\Column(type="integer") 
     */
    private int $id;

    /** 
     * @ORM\Column(type="string", length=180, unique=true) 
     */
    private string $email;

    /** 
     * @ORM\Column(type="string") 
     */
    private string $password;

    /**
     * @ORM\Column(type="json")
     */
    private array $roles = [];

    /**
     * @ORM\OneToMany(targetEntity="App\Entity\Team", mappedBy="owner")
     */
    private Collection $teams;

    /**
     * @ORM\ManyToMany(targetEntity="App\Entity\Role", inversedBy="uzytkownicy")
     * @ORM\JoinTable(name="uzytkownik_role")
     */
    private Collection $roleEntities;

    public function __construct()
    {
        $this->teams = new ArrayCollection();
        $this->roleEntities = new ArrayCollection();
    }

    // UserInterface methods: getUsername(), getRoles(), getPassword(), getSalt(), eraseCredentials()

    public function addTeam(Team $team): self
    {
        if (!$this->teams->contains($team)) {
            $this->teams->add($team);
            $team->setOwner($this);
        }
        return $this;
    }

    public function removeTeam(Team $team): self
    {
        if ($this->teams->removeElement($team)) {
            if ($team->getOwner() === $this) {
                $team->setOwner(null);
            }
        }
        return $this;
    }

    public function addRoleEntity(Role $role): self
    {
        if (!$this->roleEntities->contains($role)) {
            $this->roleEntities->add($role);
            $role->addUser($this);
        }
        return $this;
    }

    public function removeRoleEntity(Role $role): self
    {
        if ($this->roleEntities->removeElement($role)) {
            $role->removeUser($this);
        }
        return $this;
    }

    // getters/setters...
}
```

### 3.9. Role

```php
<?php
// src/Entity/Role.php
namespace App\Entity;

use Doctrine\ORM\Mapping as ORM;
use Doctrine\Common\Collections\ArrayCollection;
use Doctrine\Common\Collections\Collection;

/**
 * @ORM\Entity
 * @ORM\Table(name="role")
 */
class Role
{
    /** 
     * @ORM\Id @ORM\GeneratedValue @ORM\Column(type="integer") 
     */
    private int $id;

    /** 
     * @ORM\Column(type="string", length=50, unique=true) 
     */
    private string $name; // np. ROLE_ADMIN, ROLE_COACH

    /**
     * @ORM\ManyToMany(targetEntity="App\Entity\Permission", inversedBy="role")
     * @ORM\JoinTable(name="role_permission")
     */
    private Collection $permissions;

    /**
     * @ORM\ManyToMany(targetEntity="App\Entity\User", mappedBy="roleEntities")
     */
    private Collection $users;

    public function __construct()
    {
        $this->permissions = new ArrayCollection();
        $this->users = new ArrayCollection();
    }
  
    public function addPermission(Permission $permission): self
    {
        if (!$this->permissions->contains($permission)) {
            $this->permissions->add($permission);
            $permission->addRole($this);
        }
        return $this;
    }

    public function removePermission(Permission $permission): self
    {
        if ($this->permissions->removeElement($permission)) {
            $permission->removeRole($this);
        }
        return $this;
    }

    public function addUser(User $user): self
    {
        if (!$this->users->contains($user)) {
            $this->users->add($user);
            $user->addRoleEntity($this);
        }
        return $this;
    }

    public function removeUser(User $user): self
    {
        if ($this->users->removeElement($user)) {
            $user->removeRoleEntity($this);
        }
        return $this;
    }


    // getters/setters...
}
```

### 3.10. Permission

```php
<?php
// src/Entity/Permission.php
namespace App\Entity;

use Doctrine\ORM\Mapping as ORM;
use Doctrine\Common\Collections\ArrayCollection;
use Doctrine\Common\Collections\Collection;

/**
 * @ORM\Entity
 * @ORM\Table(name="permission")
 */
class Permission
{
    /** 
     * @ORM\Id @ORM\GeneratedValue @ORM\Column(type="integer") 
     */
    private int $id;

    /** 
     * @ORM\Column(type="string", length=100, unique=true) 
     */
    private string $name; // np. drużyna-edit-own

    /**
     * @ORM\ManyToMany(targetEntity="App\Entity\Role", mappedBy="permissions")
     */
    private Collection $role;

    public function __construct()
    {
        $this->role = new ArrayCollection();
    }
  
    public function addRole(Role $role): self
    {
        if (!$this->role->contains($role)) {
            $this->role->add($role);
            $role->addPermission($this);
        }
        return $this;
    }

    public function removeRole(Role $role): self
    {
        if ($this->role->removeElement($role)) {
            $role->removePermission($this);
        }
        return $this;
    }


    // getters/setters...
}
```

### 3.11. Log

```php
<?php
// src/Entity/Log.php
namespace App\Entity;

use Doctrine\ORM\Mapping as ORM;

/**
 * @ORM\Entity
 * @ORM\Table(name="log")
 */
class Log
{
    /** 
     * @ORM\Id @ORM\GeneratedValue @ORM\Column(type="integer") 
     */
    private int $id;

    /**
     * @ORM\ManyToOne(targetEntity="App\Entity\User")
     * @ORM\JoinColumn(nullable=false)
     */
    private User $user;

    /** 
     * @ORM\Column(type="string", length=50) 
     */
    private string $module;

    /** 
     * @ORM\Column(type="string", length=50) 
     */
    private string $action;

    /** 
     * @ORM\Column(type="text", nullable=true) 
     */
    private ?string $descriptions = null;

    /** 
     * @ORM\Column(type="datetime") 
     */
    private \DateTimeInterface $timestamp;

    // getters/setters...
}
```

Każdą z powyższych encji należy uzupełnić standardowymi metodami `getX()`, `setX()`, a tam gdzie kolekcje: `addX()`, `removeX()`. Po umieszczeniu wszystkich plików w `src/Entity` możesz wygenerować migrację i uruchomić ją, a następnie – jeśli potrzeba – CRUD-y dla wybranych encji.

Takie metody ( `addX()`, `removeX()`) pozwolą na poprawne zarządzanie kolekcjami i zachowanie spójności relacji dwukierunkowych. Po wklejeniu ich do klas, pamiętaj o `use Doctrine\Common\Collections\Collection;` i `use Doctrine\Common\Collections\ArrayCollection;` w nagłówku każdej encji.



## 4. Utworzenie migracji i zastosowanie jej w bazie

### 4.1. **Wygeneruj migrację** (porówna definicje encji z aktualnym stanem bazy):

```bash
php bin/console doctrine:migrations:diff
```

### 4.2. **Zastosuj migrację** w bazie:

```bash
php bin/console doctrine:migrations:migrate
```



## 5. Wygenerowanie CRUD-ów dla głównych encji

Dla szybkiego startu robimy CRUD-y (kontroler, formularz, widoki) dla najważniejszych encji: `Tournament`, `Team`, `Player`, `Group`, `Game`.

```bash
php bin/console make:crud Tournament
php bin/console make:crud Team
php bin/console make:crud Player
php bin/console make:crud Group
php bin/console make:crud Game
```

Po każdym poleceniu otrzymasz:

- `src/Controller/TournamentController.php`
- `src/Form/TournamentType.php`
- Szablony Twig w `templates/turnament/`

CRUD-y od razu pozwalają na listowanie, tworzenie, edycję i usuwanie rekordów.

## 6. Konfiguracja Security i UserProvider

### a) `security.yaml`

```yaml
# config/packages/security.yaml
security:
    encoders:
        App\Entity\User:
            algorithm: auto

    role_hierarchy:
        ROLE_ADMIN:   [ROLE_COACH, ROLE_USER]
        ROLE_COACH:   [ROLE_USER]

    providers:
        app_user_provider:
            entity:
                class: App\Entity\User
                property: email

    firewalls:
        dev:
            pattern: ^/(_(profiler|wdt)|css|images|js)/
            security: false

        main:
            anonymous: lazy
            provider: app_user_provider
            form_login:
                login_path: login
                check_path: login
            logout:
                path: logout
                target: /

    access_control:
        # tylko goście mogą wejść na ścieżkę logowania
        - { path: ^/login$, roles: IS_AUTHENTICATED_ANONYMOUSLY }
        # trenerzy i admini dostęp do CRUD drużyn, ale further checks in controller
        - { path: ^/team, roles: ROLE_COACH }
        # admin ma dostęp do wszystkiego w strefie admina
        - { path: ^/admin, roles: ROLE_ADMIN }
```

### b) Encja `User` z implementacją `UserInterface`

```php
<?php
// src/Entity/User.php
namespace App\Entity;

use Doctrine\ORM\Mapping as ORM;
use Symfony\Component\Security\Core\User\UserInterface;

/**
 * @ORM\Entity(repositoryClass=App\Repository\UserRepository::class)
 * @ORM\Table(name="user")
 */
class User implements UserInterface
{
    /** @ORM\Id @ORM\GeneratedValue @ORM\Column(type="integer") */
    private int $id;

    /** @ORM\Column(type="string", length=180, unique=true) */
    private string $email;

    /** @ORM\Column(type="json") */
    private array $roles = [];

    /** @ORM\Column(type="string") */
    private string $password;

    // ... getters i setters ...

    public function getUsername(): string
    {
        return $this->email;
    }

    public function getRoles(): array
    {
        return array_unique($this->roles);
    }

    public function setRoles(array $roles): self
    {
        $this->roles = $roles;
        return $this;
    }

    public function getPassword(): string
    {
        return $this->password;
    }

    public function getSalt(): ?string
    {
        // bcrypt/autoznaczenie nie wymaga soli
        return null;
    }

    public function eraseCredentials()
    {
        // oczyść tymczasowe dane, jeśli były
    }
}
```

### c) `UserProvider` (opcjonalnie własny, gdybyś chciał niestandardową logikę)

```php
<?php
// src/Security/UserProvider.php
namespace App\Security;

use App\Repository\UserRepository;
use Symfony\Component\Security\Core\Exception\UnsupportedUserException;
use Symfony\Component\Security\Core\User\UserInterface;
use Symfony\Component\Security\Core\User\UserProviderInterface;

class UserProvider implements UserProviderInterface
{
    public function __construct(private UserRepository $repo) {}

    public function loadUserByUsername(string $username): UserInterface
    {
        $user = $this->repo->findOneBy(['email' => $username]);
        if (!$user) {
            throw new UsernameNotFoundException(sprintf('Użytkownik %s nie znaleziony.', $username));
        }
        return $user;
    }

    public function refreshUser(UserInterface $user): UserInterface
    {
        if (!$user instanceof \App\Entity\User) {
            throw new UnsupportedUserException();
        }
        return $this->loadUserByUsername($user->getUsername());
    }

    public function supportsClass(string $class): bool
    {
        return $class === \App\Entity\User::class;
    }
}
```

### d) W `services.yaml` rejestrujemy go, jeśli używamy:

```yaml
services:
    App\Security\UserProvider:
        arguments: ['@App\Repository\UserRepository']
        tags:
            - { name: 'security.user_provider' }
```

## 7. Kontroler z ograniczeniami owner-only

### a) Voter: `src/Security/TeamVoter.php`

```php
<?php
// src/Security/TeamVoter.php
namespace App\Security;

use App\Entity\Team;
use App\Entity\User;
use Symfony\Component\Security\Core\Security;
use Symfony\Component\Security\Core\Authentication\Token\TokenInterface;
use Symfony\Component\Security\Core\Authorization\Voter\Voter;

class TeamVoter extends Voter
{
    public const VIEW   = 'view';
    public const EDIT   = 'edit';
    public const DELETE = 'delete';

    public function __construct(private Security $security) {}

    protected function supports(string $attribute, mixed $subject): bool
    {
        return in_array($attribute, [self::VIEW, self::EDIT, self::DELETE])
            && $subject instanceof Team;
    }

    protected function voteOnAttribute(string $attribute, mixed $subject, TokenInterface $token): bool
    {
        /** @var User|null $user */
        $user = $token->getUser();
        if (!$user instanceof User) {
            // anonim nie ma prawa
            return false;
        }

        /** @var Team $team */
        $team = $subject;

        // Admin ma wszystko
        if ($this->security->isGranted('ROLE_ADMIN')) {
            return true;
        }

        // Tylko owner może VIEW/EDIT/DELETE
        return $team->getOwner()->getId() === $user->getId();
    }
}
```

**Rejestracja Votera** w `config/services.yaml` (wyżej wczytane automatycznie, ale dla pewności):

```yaml
services:
    App\Security\TeamVoter:
        tags:
            - { name: security.voter }
```

### b) Kontroler: `src/Controller/TeamController.php`

```php
<?php
// src/Controller/TeamController.php
namespace App\Controller;

use App\Entity\Team;
use App\Form\TeamType;
use App\Repository\TeamRepository;
use Doctrine\ORM\EntityManagerInterface;
use Symfony\Bundle\FrameworkBundle\Controller\AbstractController;
use Symfony\Component\HttpFoundation\Request;
use Symfony\Component\HttpFoundation\Response;
use Symfony\Component\Routing\Annotation\Route;

#[Route('/team')]
class TeamController extends AbstractController
{
    #[Route('/', name: 'team_index', methods: ['GET'])]
    public function index(TeamRepository $repo): Response
    {
        // pokazujemy tylko drużyny, których owner to aktualny user (chyba, że ADMIN)
        $user = $this->getUser();
        if ($this->isGranted('ROLE_ADMIN')) {
            $teams = $repo->findAll();
        } else {
            $teams = $repo->findBy(['owner' => $user]);
        }

        return $this->render('team/index.html.twig', [
            'teams' => $teams,
        ]);
    }

    #[Route('/new', name: 'team_new', methods: ['GET','POST'])]
    public function new(Request $request, EntityManagerInterface $em): Response
    {
        $team = new Team();
        $team->setOwner($this->getUser());
        $form = $this->createForm(TeamType::class, $team);
        $form->handleRequest($request);

        if ($form->isSubmitted() && $form->isValid()) {
            $em->persist($team);
            $em->flush();

            return $this->redirectToRoute('team_index');
        }

        return $this->render('team/new.html.twig', [
            'form' => $form->createView(),
        ]);
    }

    #[Route('/{id}', name: 'team_show', methods: ['GET'])]
    public function show(Team $team): Response
    {
        $this->denyAccessUnlessGranted('view', $team);

        return $this->render('team/show.html.twig', [
            'team' => $team,
        ]);
    }

    #[Route('/{id}/edit', name: 'team_edit', methods: ['GET','POST'])]
    public function edit(Request $request, Team $team, EntityManagerInterface $em): Response
    {
        $this->denyAccessUnlessGranted('edit', $team);

        $form = $this->createForm(TeamType::class, $team);
        $form->handleRequest($request);

        if ($form->isSubmitted() && $form->isValid()) {
            $em->flush();
            return $this->redirectToRoute('team_index');
        }

        return $this->render('team/edit.html.twig', [
            'form' => $form->createView(),
            'team' => $team,
        ]);
    }

    #[Route('/{id}', name: 'team_delete', methods: ['POST'])]
    public function delete(Request $request, Team $team, EntityManagerInterface $em): Response
    {
        $this->denyAccessUnlessGranted('delete', $team);

        if ($this->isCsrfTokenValid('delete'.$team->getId(), $request->request->get('_token'))) {
            $em->remove($team);
            $em->flush();
        }

        return $this->redirectToRoute('team_index');
    }
}
```

Dzięki Voterowi i `denyAccessUnlessGranted()` mamy pewność, że tylko właściciel drużyny (lub admin) może ją oglądać, edytować i usuwać.



## 8. Logger i listenerzy do tabeli `Log`

Chcemy zapisywać każde tworzenie, edycję i usunięcie kluczowych encji w tabeli `log`.

### a) `LogSubscriber`: `src/EventSubscriber/LogSubscriber.php`

```php
<?php
// src/EventSubscriber/LogSubscriber.php
namespace App\EventSubscriber;

use App\Entity\Log;
use Doctrine\Common\EventSubscriber;
use Doctrine\ORM\Event\OnFlushEventArgs;
use Doctrine\ORM\Events;
use Symfony\Component\Security\Core\Security;

class LogSubscriber implements EventSubscriber
{
    public function __construct(private Security $security) {}

    public function getSubscribedEvents(): array
    {
        return [
            Events::onFlush,
        ];
    }

    public function onFlush(OnFlushEventArgs $args): void
    {
        $em        = $args->getEntityManager();
        $uow       = $em->getUnitOfWork();
        $now       = new \DateTimeImmutable();
        $user      = $this->security->getUser();
        $username  = $user ? $user->getUsername() : 'anonymous';

        // helper to map change sets
        $formatChanges = fn(array $cs): string => json_encode($cs);

        // 1. New objects
        foreach ($uow->getScheduledEntityInsertions() as $entity) {
            $log = (new Log())
                ->setUser($user)
                ->setModul(self::class)
                ->setAkcja('CREATE '.get_class($entity))
                ->setOpis($formatChanges($uow->getEntityChangeSet($entity)))
                ->setTimestamp($now);
            $em->persist($log);
            $uow->computeChangeSet($em->getClassMetadata(Log::class), $log);
        }

        // 2. Updated objects
        foreach ($uow->getScheduledEntityUpdates() as $entity) {
            $log = (new Log())
                ->setUser($user)
                ->setModul(self::class)
                ->setAkcja('UPDATE '.get_class($entity))
                ->setOpis($formatChanges($uow->getEntityChangeSet($entity)))
                ->setTimestamp($now);
            $em->persist($log);
            $uow->computeChangeSet($em->getClassMetadata(Log::class), $log);
        }

        // 3. Removed objects
        foreach ($uow->getScheduledEntityDeletions() as $entity) {
            $log = (new Log())
                ->setUser($user)
                ->setModul(self::class)
                ->setAkcja('DELETE '.get_class($entity))
                ->setOpis(null)
                ->setTimestamp($now);
            $em->persist($log);
            $uow->computeChangeSet($em->getClassMetadata(Log::class), $log);
        }
    }
}
```

### b) Rejestracja subskrybenta w `config/services.yaml`

```yaml
services:
    App\EventSubscriber\LogSubscriber:
        arguments:
            $security: '@security.helper'
        tags:
            - { name: doctrine.event_subscriber }
```

### c) Konfiguracja Monolog (opcjonalnie)

Jeśli chcesz, żeby również standardowe logi Symfony były zapisywane do pliku, upewnij się w `config/packages/monolog.yaml`:

```yaml
monolog:
    channels: ['app']   # własny kanał
    handlers:
        main:
            type: fingers_crossed
            action_level: error
            handler: nested
        nested:
            type: stream
            path: '%kernel.logs_dir%/%kernel.environment%.log'
            level: debug
        console:
            type: console
            process_psr_3_messages: false
            channels: ['!event', '!doctrine']
        # można dodać handler np. do bazy, ale mamy już LogSubscriber
```

