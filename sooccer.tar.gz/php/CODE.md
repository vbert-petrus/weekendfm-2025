### SQL

```sql
CREATE TABLE users (
    id INT AUTO_INCREMENT PRIMARY KEY,
    username VARCHAR(50) UNIQUE NOT NULL,
    password_hash VARCHAR(255) NOT NULL,
    role ENUM('admin', 'organizer', 'viewer') NOT NULL
);

CREATE TABLE tournaments (
    id INT AUTO_INCREMENT PRIMARY KEY,
    name VARCHAR(100) NOT NULL,
    year INT NOT NULL,
    team_size INT NOT NULL,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
);

CREATE TABLE teams (
    id INT AUTO_INCREMENT PRIMARY KEY,
    tournament_id INT NOT NULL,
    name VARCHAR(100) NOT NULL,
    FOREIGN KEY (tournament_id) REFERENCES tournaments(id)
);

CREATE TABLE players (
    id INT AUTO_INCREMENT PRIMARY KEY,
    team_id INT NOT NULL,
    name VARCHAR(100) NOT NULL,
    birth_date DATE NOT NULL,
    FOREIGN KEY (team_id) REFERENCES teams(id)
);

CREATE TABLE groups (
    id INT AUTO_INCREMENT PRIMARY KEY,
    tournament_id INT NOT NULL,
    name VARCHAR(50) NOT NULL,
    FOREIGN KEY (tournament_id) REFERENCES tournaments(id)
);

CREATE TABLE group_matches (
    id INT AUTO_INCREMENT PRIMARY KEY,
    group_id INT NOT NULL,
    home_team_id INT NOT NULL,
    away_team_id INT NOT NULL,
    home_team_score INT DEFAULT 0,
    away_team_score INT DEFAULT 0,
    match_date TIMESTAMP NOT NULL,
    FOREIGN KEY (group_id) REFERENCES groups(id),
    FOREIGN KEY (home_team_id) REFERENCES teams(id),
    FOREIGN KEY (away_team_id) REFERENCES teams(id)
);

CREATE TABLE knockout_matches (
    id INT AUTO_INCREMENT PRIMARY KEY,
    tournament_id INT NOT NULL,
    home_team_id INT NOT NULL,
    away_team_id INT NOT NULL,
    home_team_score INT DEFAULT 0,
    away_team_score INT DEFAULT 0,
    match_date TIMESTAMP NOT NULL,
    FOREIGN KEY (tournament_id) REFERENCES tournaments(id),
    FOREIGN KEY (home_team_id) REFERENCES teams(id),
    FOREIGN KEY (away_team_id) REFERENCES teams(id)
);

CREATE TABLE logs (
    id INT AUTO_INCREMENT PRIMARY KEY,
    user_id INT NOT NULL,
    action VARCHAR(255) NOT NULL,
    log_time TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    FOREIGN KEY (user_id) REFERENCES users(id)
);

```

### **Moduł logowania zdarzeń**

Każda akcja w aplikacji powinna być logowana, np. dodanie nowego turnieju.

```php
function logAction($user_id, $action) {
    global $pdo;
    $stmt = $pdo->prepare('INSERT INTO logs (user_id, action) VALUES (?, ?)');
    $stmt->execute([$user_id, $action]);
}

// Przykład logowania:
logAction($_SESSION['user_id'], 'Utworzono nowy turniej o nazwie "Junior Cup 2024"');

```

### **Obsługa błędów**

Używaj wyjątków i obsługi błędów:

```php
try {
    // Kod operacji na bazie danych
    $pdo->beginTransaction();
    // Operacje...
    $pdo->commit();
} catch (Exception $e) {
    $pdo->rollBack();
    echo "Błąd: " . $e->getMessage();
}

```



### 1. **Moduł Autoryzacji i Użytkowników**

#### Struktura klasy `User`

```php
class User {
    private $id;
    private $username;
    private $passwordHash;
    private $role;
    private $pdo;

    public function __construct($pdo) {
        $this->pdo = $pdo;
    }

    public function create($username, $password, $role) {
        $this->passwordHash = password_hash($password, PASSWORD_BCRYPT);
        $stmt = $this->pdo->prepare('INSERT INTO users (username, password_hash, role) VALUES (?, ?, ?)');
        if ($stmt->execute([$username, $this->passwordHash, $role])) {
            return true;
        }
        return false;
    }

    public function login($username, $password) {
        $stmt = $this->pdo->prepare('SELECT * FROM users WHERE username = ?');
        $stmt->execute([$username]);
        $user = $stmt->fetch();

        if ($user && password_verify($password, $user['password_hash'])) {
            $_SESSION['user_id'] = $user['id'];
            $_SESSION['role'] = $user['role'];
            return true;
        }
        return false;
    }

    public static function isAuthorized($role) {
        return isset($_SESSION['role']) && $_SESSION['role'] === $role;
    }

    public static function logout() {
        session_destroy();
    }
}

```

#### Obsługa błędów i widoki

1. Formularz logowania (`login.php`)

```php+HTML
<?php
// Sprawdzenie, czy użytkownik już jest zalogowany
session_start();
if (isset($_SESSION['user_id'])) {
    header("Location: dashboard.php");
    exit;
}

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    require_once 'database.php';
    $user = new User($pdo);
    if ($user->login($_POST['username'], $_POST['password'])) {
        header("Location: dashboard.php");
        exit;
    } else {
        $error = "Nieprawidłowy login lub hasło.";
    }
}
?>
<!DOCTYPE html>
<html>
<head><title>Login</title></head>
<body>
    <h1>Login</h1>
    <form method="POST">
        <input type="text" name="username" placeholder="Username" required />
        <input type="password" name="password" placeholder="Password" required />
        <button type="submit">Login</button>
    </form>
    <?php if (isset($error)) echo "<p>$error</p>"; ?>
</body>
</html>

```

2. Dashboard użytkownika (`dashboard.php`)

```php+HTML
<?php
session_start();
if (!User::isAuthorized('admin')) {
    header("Location: login.php");
    exit;
}

echo "Witaj, " . $_SESSION['role'] . "!";
?>
<!DOCTYPE html>
<html>
<head><title>Dashboard</title></head>
<body>
    <h1>Panel administracyjny</h1>
    <a href="logout.php">Wyloguj się</a>
</body>
</html>

```

3. Wylogowanie (`logout.php`)

```php
<?php
session_start();
User::logout();
header("Location: login.php");
exit;

```

### 2. **Moduł Turniej**

#### Struktura klasy `Tournament`

```php
class Tournament {
    private $pdo;

    public function __construct($pdo) {
        $this->pdo = $pdo;
    }
    
    // Pobierz listę użytkowników z rolą "organizer"
    public function getOrganizers() {
        $stmt = $this->pdo->query("SELECT id, username FROM users WHERE role = 'organizer'");
        return $stmt->fetchAll();
    }

    public function create($name, $year, $teamSize, $organizerId) {
        // Walidacja danych na poziomie serwera
        if (empty($name) || !is_numeric($year) || !is_numeric($teamSize)) {
            throw new Exception('Błędne dane: Nazwa, rok oraz liczba zawodników muszą być poprawne.');
        }

        if ($year < 2000 || $year > date('Y')) {
            throw new Exception('Błędny rok: Turniej musi być w zakresie od 2000 do ' . date('Y') . '.');
        }

        if ($teamSize < 5 || $teamSize > 30) {
            throw new Exception('Liczba zawodników musi być w zakresie od 5 do 30.');
        }

        // Wstawienie danych do bazy
        $stmt = $this->pdo->prepare('INSERT INTO tournaments (name, year, team_size, organizer_id) VALUES (?, ?, ?, ?)');
        if (!$stmt->execute([$name, $year, $teamSize, $organizerId])) {
            throw new Exception('Nie udało się utworzyć turnieju.');
        }
        return true;
    }

    public function getAll() {
        $stmt = $this->pdo->query('SELECT * FROM tournaments');
        return $stmt->fetchAll();
    }
}

```

Widok tworzenia turnieju (`create_tournament.php`)

```php+HTML
<?php
session_start();
if (!User::isAuthorized('organizer')) {
    header("Location: login.php");
    exit;
}

require_once 'database.php';
$tournament = new Tournament($pdo);
$organizers = $tournament->getOrganizers();

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    try {
        $tournament->create($_POST['name'], $_POST['year'], $_POST['team_size'], $_POST['organizer_id']);
        $success = "Turniej został pomyślnie utworzony!";
    } catch (Exception $e) {
        $error = $e->getMessage();
    }
}
?>

<!DOCTYPE html>
<html lang="pl">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Utwórz Turniej</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">
    <link href="https://cdnjs.cloudflare.com/ajax/libs/bootstrap-icons/1.11.3/font/bootstrap-icons.css" rel="stylesheet">
</head>
<body class="bg-light">
    <div class="container mt-5">
        <div class="card shadow">
            <div class="card-body">
                <h1 class="card-title mb-4">Utwórz nowy turniej</h1>

                <!-- Komunikaty -->
                <?php if (isset($success)) : ?>
                    <div class="alert alert-success"><?php echo $success; ?></div>
                <?php endif; ?>

                <?php if (isset($error)) : ?>
                    <div class="alert alert-danger"><?php echo $error; ?></div>
                <?php endif; ?>

                <form method="POST" class="needs-validation" novalidate>
                    <!-- Nazwa turnieju -->
                    <div class="mb-3">
                        <label for="name" class="form-label">Nazwa turnieju</label>
                        <input type="text" id="name" name="name" class="form-control" placeholder="Wprowadź nazwę turnieju" required>
                        <div class="invalid-feedback">Proszę podać nazwę turnieju.</div>
                    </div>

                    <!-- Rok -->
                    <div class="mb-3">
                        <label for="year" class="form-label">Rok</label>
                        <input type="number" id="year" name="year" class="form-control" placeholder="Rok turnieju" min="2000" max="<?php echo date('Y'); ?>" required>
                        <div class="invalid-feedback">Proszę podać rok w zakresie od 2000 do <?php echo date('Y'); ?>.</div>
                    </div>

                    <!-- Liczba zawodników -->
                    <div class="mb-3">
                        <label for="team_size" class="form-label">Liczba zawodników</label>
                        <input type="number" id="team_size" name="team_size" class="form-control" placeholder="Liczba zawodników w drużynie" min="5" max="30" required>
                        <div class="invalid-feedback">Liczba zawodników musi być między 5 a 30.</div>
                    </div>

                    <!-- Organizator -->
                    <div class="mb-3">
                        <label for="organizer_id" class="form-label">Organizator</label>
                        <select id="organizer_id" name="organizer_id" class="form-select" required>
                            <option value="" disabled selected>Wybierz organizatora</option>
                            <?php foreach ($organizers as $organizer) : ?>
                                <option value="<?php echo $organizer['id']; ?>"><?php echo $organizer['username']; ?></option>
                            <?php endforeach; ?>
                        </select>
                        <div class="invalid-feedback">Proszę wybrać organizatora turnieju.</div>
                    </div>

                    <button type="submit" class="btn btn-primary"><i class="bi bi-plus-circle"></i> Utwórz</button>
                </form>
            </div>
        </div>
    </div>

    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/js/bootstrap.bundle.min.js"></script>
    <script>
        (() => {
            'use strict';
            const forms = document.querySelectorAll('.needs-validation');
            Array.from(forms).forEach(form => {
                form.addEventListener('submit', event => {
                    if (!form.checkValidity()) {
                        event.preventDefault();
                        event.stopPropagation();
                    }
                    form.classList.add('was-validated');
                }, false);
            });
        })();
    </script>
</body>
</html>
```

Widok listy turniejów (`list_tournaments.php`)

```php+HTML
<?php
session_start();
if (!User::isAuthorized('organizer')) {
    header("Location: login.php");
    exit;
}

require_once 'database.php';
$tournament = new Tournament($pdo);
$tournaments = $tournament->getAll();
?>

<!DOCTYPE html>
<html>
<head><title>Lista Turniejów</title></head>
<body>
    <h1>Lista Turniejów</h1>
    <ul>
        <?php foreach ($tournaments as $t) : ?>
            <li><?php echo $t['name']; ?> (Rok: <?php echo $t['year']; ?>, Zawodnicy: <?php echo $t['team_size']; ?>)</li>
        <?php endforeach; ?>
    </ul>
</body>
</html>

```

### 3. **Moduł Zawodników**

#### Struktura klasy `Player`

```php
class Player {
    private $pdo;

    public function __construct($pdo) {
        $this->pdo = $pdo;
    }

    public function add($teamId, $name, $birthDate) {
        if (empty($name) || empty($birthDate)) {
            throw new Exception('Brakujące dane zawodnika');
        }

        $stmt = $this->pdo->prepare('INSERT INTO players (team_id, name, birth_date) VALUES (?, ?, ?)');
        if (!$stmt->execute([$teamId, $name, $birthDate])) {
            throw new Exception('Nie udało się dodać zawodnika');
        }
        return true;
    }

    public function getByTeam($teamId) {
        $stmt = $this->pdo->prepare('SELECT * FROM players WHERE team_id = ?');
        $stmt->execute([$teamId]);
        return $stmt->fetchAll();
    }
}

```

Widok dodawania zawodników (`add_player.php`)

```php+HTML
<?php
session_start();
if (!User::isAuthorized('organizer')) {
    header("Location: login.php");
    exit;
}

require_once 'database.php';
$player = new Player($pdo);

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    try {
        $player->add($_POST['team_id'], $_POST['name'], $_POST['birth_date']);
        echo "Zawodnik został pomyślnie dodany!";
    } catch (Exception $e) {
        $error = $e->getMessage();
    }
}
?>

<!DOCTYPE html>
<html>
<head><title>Dodaj Zawodnika</title></head>
<body>
    <h1>Dodaj nowego zawodnika</h1>
    <form method="POST">
        <input type="number" name="team_id" placeholder="ID drużyny" required />
        <input type="text" name="name" placeholder="Imię i nazwisko zawodnika" required />
        <input type="date" name="birth_date" required />
        <button type="submit">Dodaj</button>
    </form>
    <?php if (isset($error)) echo "<p>$error</p>"; ?>
</body>
</html>

```

### 4. **Moduł Drużyny**

#### Struktura klasy `Team`

```php
class Team {
    private $pdo;

    public function __construct($pdo) {
        $this->pdo = $pdo;
    }

    public function create($tournamentId, $name) {
        if (empty($name) || !is_numeric($tournamentId)) {
            throw new Exception('Błędne dane drużyny');
        }

        $stmt = $this->pdo->prepare('INSERT INTO teams (tournament_id, name) VALUES (?, ?)');
        if (!$stmt->execute([$tournamentId, $name])) {
            throw new Exception('Nie udało się dodać drużyny');
        }
        return true;
    }

    public function getAllByTournament($tournamentId) {
        $stmt = $this->pdo->prepare('SELECT * FROM teams WHERE tournament_id = ?');
        $stmt->execute([$tournamentId]);
        return $stmt->fetchAll();
    }

    public function assignPlayer($teamId, $playerId) {
        $stmt = $this->pdo->prepare('UPDATE players SET team_id = ? WHERE id = ?');
        if (!$stmt->execute([$teamId, $playerId])) {
            throw new Exception('Nie udało się przypisać zawodnika do drużyny');
        }
        return true;
    }
}

```

Widok tworzenia drużyny (`create_team.php`)

```php+HTML
<?php
session_start();
if (!User::isAuthorized('organizer')) {
    header("Location: login.php");
    exit;
}

require_once 'database.php';
$team = new Team($pdo);

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    try {
        $team->create($_POST['tournament_id'], $_POST['name']);
        echo "Drużyna została pomyślnie utworzona!";
    } catch (Exception $e) {
        $error = $e->getMessage();
    }
}
?>

<!DOCTYPE html>
<html>
<head><title>Utwórz Drużynę</title></head>
<body>
    <h1>Utwórz nową drużynę</h1>
    <form method="POST">
        <input type="number" name="tournament_id" placeholder="ID Turnieju" required />
        <input type="text" name="name" placeholder="Nazwa drużyny" required />
        <button type="submit">Utwórz</button>
    </form>
    <?php if (isset($error)) echo "<p>$error</p>"; ?>
</body>
</html>

```

Widok przypisania zawodnika do drużyny (`assign_player.php`)

```php+HTML
<?php
session_start();
if (!User::isAuthorized('organizer')) {
    header("Location: login.php");
    exit;
}

require_once 'database.php';
$team = new Team($pdo);

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    try {
        $team->assignPlayer($_POST['team_id'], $_POST['player_id']);
        echo "Zawodnik został przypisany do drużyny!";
    } catch (Exception $e) {
        $error = $e->getMessage();
    }
}
?>

<!DOCTYPE html>
<html>
<head><title>Przypisz Zawodnika</title></head>
<body>
    <h1>Przypisz zawodnika do drużyny</h1>
    <form method="POST">
        <input type="number" name="team_id" placeholder="ID Drużyny" required />
        <input type="number" name="player_id" placeholder="ID Zawodnika" required />
        <button type="submit">Przypisz</button>
    </form>
    <?php if (isset($error)) echo "<p>$error</p>"; ?>
</body>
</html>

```

### 5. **Moduł Grupy**

#### Struktura klasy `Group`

```php
class Group {
    private $pdo;

    public function __construct($pdo) {
        $this->pdo = $pdo;
    }

    public function create($tournamentId, $name) {
        if (empty($name) || !is_numeric($tournamentId)) {
            throw new Exception('Błędne dane grupy');
        }

        $stmt = $this->pdo->prepare('INSERT INTO groups (tournament_id, name) VALUES (?, ?)');
        if (!$stmt->execute([$tournamentId, $name])) {
            throw new Exception('Nie udało się utworzyć grupy');
        }
        return true;
    }

    public function assignTeamToGroup($groupId, $teamId) {
        $stmt = $this->pdo->prepare('INSERT INTO group_teams (group_id, team_id) VALUES (?, ?)');
        if (!$stmt->execute([$groupId, $teamId])) {
            throw new Exception('Nie udało się przypisać drużyny do grupy');
        }
        return true;
    }

    public function getAllByTournament($tournamentId) {
        $stmt = $this->pdo->prepare('SELECT * FROM groups WHERE tournament_id = ?');
        $stmt->execute([$tournamentId]);
        return $stmt->fetchAll();
    }
}

```

Widok tworzenia grupy (`create_group.php`)

```php+HTML
<?php
session_start();
if (!User::isAuthorized('organizer')) {
    header("Location: login.php");
    exit;
}

require_once 'database.php';
$group = new Group($pdo);

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    try {
        $group->create($_POST['tournament_id'], $_POST['name']);
        echo "Grupa została pomyślnie utworzona!";
    } catch (Exception $e) {
        $error = $e->getMessage();
    }
}
?>

<!DOCTYPE html>
<html>
<head><title>Utwórz Grupę</title></head>
<body>
    <h1>Utwórz nową grupę</h1>
    <form method="POST">
        <input type="number" name="tournament_id" placeholder="ID Turnieju" required />
        <input type="text" name="name" placeholder="Nazwa grupy" required />
        <button type="submit">Utwórz</button>
    </form>
    <?php if (isset($error)) echo "<p>$error</p>"; ?>
</body>
</html>

```

Widok przypisania drużyny do grupy (`assign_team_to_group.php`)

```php+HTML
<?php
session_start();
if (!User::isAuthorized('organizer')) {
    header("Location: login.php");
    exit;
}

require_once 'database.php';
$group = new Group($pdo);

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    try {
        $group->assignTeamToGroup($_POST['group_id'], $_POST['team_id']);
        echo "Drużyna została przypisana do grupy!";
    } catch (Exception $e) {
        $error = $e->getMessage();
    }
}
?>

<!DOCTYPE html>
<html>
<head><title>Przypisz Drużynę do Grupy</title></head>
<body>
    <h1>Przypisz drużynę do grupy</h1>
    <form method="POST">
        <input type="number" name="group_id" placeholder="ID Grupy" required />
        <input type="number" name="team_id" placeholder="ID Drużyny" required />
        <button type="submit">Przypisz</button>
    </form>
    <?php if (isset($error)) echo "<p>$error</p>"; ?>
</body>
</html>

```

### 6. **Moduł Mecze Grupowe**

#### Struktura klasy `GroupMatch`

```php
class GroupMatch {
    private $pdo;

    public function __construct($pdo) {
        $this->pdo = $pdo;
    }

    public function schedule($groupId, $homeTeamId, $awayTeamId, $matchDate) {
        if (empty($groupId) || empty($homeTeamId) || empty($awayTeamId) || empty($matchDate)) {
            throw new Exception('Błędne dane meczu');
        }

        $stmt = $this->pdo->prepare('INSERT INTO group_matches (group_id, home_team_id, away_team_id, match_date) VALUES (?, ?, ?, ?)');
        if (!$stmt->execute([$groupId, $homeTeamId, $awayTeamId, $matchDate])) {
            throw new Exception('Nie udało się zaplanować meczu');
        }
        return true;
    }

    public function getByGroup($groupId) {
        $stmt = $this->pdo->prepare('SELECT * FROM group_matches WHERE group_id = ?');
        $stmt->execute([$groupId]);
        return $stmt->fetchAll();
    }
}

```

Widok planowania meczu (`schedule_group_match.php`)

```php+HTML
<?php
session_start();
if (!User::isAuthorized('organizer')) {
    header("Location: login.php");
    exit;
}

require_once 'database.php';
$match = new GroupMatch($pdo);

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    try {
        $match->schedule($_POST['group_id'], $_POST['home_team_id'], $_POST['away_team_id'], $_POST['match_date']);
        echo "Mecz został zaplanowany!";
    } catch (Exception $e) {
        $error = $e->getMessage();
    }
}
?>

<!DOCTYPE html>
<html>
<head><title>Planowanie Meczu Grupowego</title></head>
<body>
    <h1>Zaplanuj mecz grupowy</h1>
    <form method="POST">
        <input type="number" name="group_id" placeholder="ID Grupy" required />
        <input type="number" name="home_team_id" placeholder="ID Drużyny Gospodarzy" required />
        <input type="number" name="away_team_id" placeholder="ID Drużyny Gości" required />
        <input type="datetime-local" name="match_date" required />
        <button type="submit">Zaplanuj mecz</button>
    </form>
    <?php if (isset($error)) echo "<p>$error</p>"; ?>
</body>
</html>

```

### 7. **Moduł Faza Pucharowa**

#### Struktura klasy `KnockoutMatch`

```php
class KnockoutMatch {
    private $pdo;

    public function __construct($pdo) {
        $this->pdo = $pdo;
    }

    public function generateKnockout($tournamentId) {
        // Wygenerowanie par na podstawie wyników fazy grupowej
        $stmt = $this->pdo->prepare('SELECT team_id, SUM(points) AS points FROM group_matches WHERE tournament_id = ? GROUP BY team_id ORDER BY points DESC');
        $stmt->execute([$tournamentId]);
        $teams = $stmt->fetchAll();

        // Ustawienie par
        $pairs = [];
        for ($i = 0; $i < count($teams) / 2; $i++) {
            $pairs[] = [$teams[$i]['team_id'], $teams[count($teams) - 1 - $i]['team_id']];
        }

        // Zapis par do bazy
        foreach ($pairs as $pair) {
            $stmt = $this->pdo->prepare('INSERT INTO knockout_matches (tournament_id, home_team_id, away_team_id) VALUES (?, ?, ?)');
            $stmt->execute([$tournamentId, $pair[0], $pair[1]]);
        }

        return true;
    }

    public function getByTournament($tournamentId) {
        $stmt = $this->pdo->prepare('SELECT * FROM knockout_matches WHERE tournament_id = ?');
        $stmt->execute([$tournamentId]);
        return $stmt->fetchAll();
    }
}

```

Widok generowania fazy pucharowej (`generate_knockout.php`)

```php+HTML
<?php
session_start();
if (!User::isAuthorized('organizer')) {
    header("Location: login.php");
    exit;
}

require_once 'database.php';
$knockout = new KnockoutMatch($pdo);

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    try {
        $knockout->generateKnockout($_POST['tournament_id']);
        echo "Drabinka pucharowa została wygenerowana!";
    } catch (Exception $e) {
        $error = $e->getMessage();
    }
}
?>

<!DOCTYPE html>
<html>
<head><title>Generowanie Fazy Pucharowej</title></head>
<body>
    <h1>Generuj Faza Pucharowa</h1>
    <form method="POST">
        <input type="number" name="tournament_id" placeholder="ID Turnieju" required />
        <button type="submit">Generuj</button>
    </form>
    <?php if (isset($error)) echo "<p>$error</p>"; ?>
</body>
</html>

```

